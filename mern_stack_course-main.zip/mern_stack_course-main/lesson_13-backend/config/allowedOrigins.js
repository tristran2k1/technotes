const allowedOrigins = [
    'https://technotes.onrender.com'
]

module.exports = allowedOrigins
const NotesList = () => {
    return (
        <h1>NotesList</h1>
    )
}
export default NotesList